var require = meteorInstall({"lib":{"collections.js":["meteor/mongo","./schemas",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.Tiles = undefined;                                                                                           //
                                                                                                                     //
var _mongo = require('meteor/mongo');                                                                                // 1
                                                                                                                     //
var _schemas = require('./schemas');                                                                                 // 2
                                                                                                                     //
var Tiles = exports.Tiles = new _mongo.Mongo.Collection('tiles');                                                    // 4
Tiles.attachSchema(_schemas.TileSchema);                                                                             // 5
                                                                                                                     //
// Tiles.helpers( {                                                                                                  //
//     getAll ( ) {                                                                                                  //
//         return this.find( {}, { sort: { relTimestamp: 1 } } );                                                    //
//     },                                                                                                            //
//     getSocial ( ) {},                                                                                             //
//     getPosts ( ) {},                                                                                              //
//     getActivities ( ) {},                                                                                         //
//     getEvents ( ) {}                                                                                              //
// } );                                                                                                              //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"router.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/router.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var TileSubs = new SubsManager();                                                                                    // 1
                                                                                                                     //
FlowRouter.route('/', {                                                                                              // 3
  name: 'App',                                                                                                       // 4
  subscriptions: function () {                                                                                       // 5
    function subscriptions(params, queryParams) {                                                                    // 5
      this.register('tiles', TileSubs.subscribe('tiles.public'));                                                    // 6
    }                                                                                                                //
                                                                                                                     //
    return subscriptions;                                                                                            //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
FlowRouter.route('/health', {                                                                                        // 10
  name: 'Health'                                                                                                     // 11
  //                                                                                                                 //
  //   this.response.statusCode = 200;                                                                               //
  //   this.response.end( this.response.statusCode.toString() );                                                     //
});                                                                                                                  // 10
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":["meteor/aldeed:simple-schema",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/schemas.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.TileSchema = undefined;                                                                                      //
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 1
                                                                                                                     //
var TileSchema = exports.TileSchema = new _aldeedSimpleSchema.SimpleSchema({                                         // 3
  key: {                                                                                                             // 4
    type: Number,                                                                                                    // 5
    label: 'ID',                                                                                                     // 6
    unique: true,                                                                                                    // 7
    optional: false                                                                                                  // 8
  },                                                                                                                 //
  timestamp: {                                                                                                       // 10
    type: Number,                                                                                                    // 11
    label: 'Timestamp',                                                                                              // 12
    optional: false                                                                                                  // 13
  },                                                                                                                 //
  relTimestamp: {                                                                                                    // 15
    type: Number,                                                                                                    // 16
    label: 'Relative Timestamp',                                                                                     // 17
    optional: false                                                                                                  // 18
  },                                                                                                                 //
  type: {                                                                                                            // 20
    type: String,                                                                                                    // 21
    label: 'Type',                                                                                                   // 22
    optional: true                                                                                                   // 23
  },                                                                                                                 //
  title: {                                                                                                           // 25
    type: String,                                                                                                    // 26
    label: 'Title',                                                                                                  // 27
    optional: true                                                                                                   // 28
  },                                                                                                                 //
  label: {                                                                                                           // 30
    type: String,                                                                                                    // 31
    label: 'Label',                                                                                                  // 32
    optional: true                                                                                                   // 33
  },                                                                                                                 //
  badge: {                                                                                                           // 35
    type: String,                                                                                                    // 36
    label: 'Badge',                                                                                                  // 37
    optional: true                                                                                                   // 38
  },                                                                                                                 //
  link: {                                                                                                            // 40
    type: String,                                                                                                    // 41
    label: 'Link',                                                                                                   // 42
    regEx: _aldeedSimpleSchema.SimpleSchema.RegEx.Url,                                                               // 43
    optional: true                                                                                                   // 44
  },                                                                                                                 //
  media: {                                                                                                           // 46
    type: [Object],                                                                                                  // 47
    label: 'Media',                                                                                                  // 48
    optional: true                                                                                                   // 49
  },                                                                                                                 //
  'media.$.url': {                                                                                                   // 51
    type: String,                                                                                                    // 52
    label: 'Media URL',                                                                                              // 53
    regEx: /^(https?:)?\/?\//,                                                                                       // 54
    optional: false                                                                                                  // 55
  },                                                                                                                 //
  caption: {                                                                                                         // 57
    type: String,                                                                                                    // 58
    label: 'Caption',                                                                                                // 59
    optional: true                                                                                                   // 60
  },                                                                                                                 //
  config: {                                                                                                          // 62
    type: Object,                                                                                                    // 63
    label: 'Tile Configuration',                                                                                     // 64
    optional: true                                                                                                   // 65
  },                                                                                                                 //
  'config.$.published': {                                                                                            // 67
    type: Boolean,                                                                                                   // 68
    label: 'Tile Published',                                                                                         // 69
    optional: true                                                                                                   // 70
  },                                                                                                                 //
  'config.$.ratio': {                                                                                                // 72
    type: String,                                                                                                    // 73
    label: 'Tile Ratio',                                                                                             // 74
    optional: true                                                                                                   // 75
  },                                                                                                                 //
  'config.$.cols': {                                                                                                 // 77
    type: Object,                                                                                                    // 78
    label: 'Tile Size per Breakpoint',                                                                               // 79
    optional: true                                                                                                   // 80
  },                                                                                                                 //
  'config.$.cols.$.xs': {                                                                                            // 82
    type: Number,                                                                                                    // 83
    label: 'Tile size ( xs )',                                                                                       // 84
    optional: true                                                                                                   // 85
  },                                                                                                                 //
  'config.$.cols.$.sm': {                                                                                            // 87
    type: Number,                                                                                                    // 88
    label: 'Tile size ( sm )',                                                                                       // 89
    optional: true                                                                                                   // 90
  },                                                                                                                 //
  'config.$.cols.$.md': {                                                                                            // 92
    type: Number,                                                                                                    // 93
    label: 'Tile size ( md )',                                                                                       // 94
    optional: true                                                                                                   // 95
  },                                                                                                                 //
  'config.$.cols.$.lg': {                                                                                            // 97
    type: Number,                                                                                                    // 98
    label: 'Tile size ( lg )',                                                                                       // 99
    optional: true                                                                                                   // 100
  }                                                                                                                  //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"imports":{"months.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/months.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
var months = exports.months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tile-config.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/tile-config.js                                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
var config = exports.config = {                                                                                      // 1
  published: true,                                                                                                   // 2
  ratio: '9-16',                                                                                                     // 3
  cols: {                                                                                                            // 4
    xs: 6,                                                                                                           // 5
    sm: 4,                                                                                                           // 6
    md: 3,                                                                                                           // 7
    lg: 3                                                                                                            // 8
  }                                                                                                                  //
};                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"endpoints.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/endpoints.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
                                                                                                                     //
// TODO: Make authorable by admin                                                                                    //
var CURALATE = exports.CURALATE = 'https://api.curalate.com/v1/reels/unitedoutside';                                 // 3
var CURALATE_QUERY = exports.CURALATE_QUERY = {                                                                      // 4
  limit: 100                                                                                                         // 5
};                                                                                                                   //
                                                                                                                     //
var WP = exports.WP = 'http://brightestyoungthings.com/api/get_recent_posts';                                        // 8
var WP_QUERY = exports.WP_QUERY = {                                                                                  // 9
  limit: 100                                                                                                         // 10
};                                                                                                                   //
                                                                                                                     //
// search: 'REI'                                                                                                     //
var EVENTS = exports.EVENTS = 'https://rei.com/rest/events/nearby';                                                  // 14
var EVENTS_QUERY = exports.EVENTS_QUERY = {                                                                          // 15
  limit: 100,                                                                                                        // 16
  sortBy: 'date',                                                                                                    // 17
  sortDirection: 'asc',                                                                                              // 18
  offset: 0,                                                                                                         // 19
  distance: 50,                                                                                                      // 20
  location: 20500                                                                                                    // 21
};                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"kadira.js":["meteor/meteor",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/kadira.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
_meteor.Meteor.startup(function () {                                                                                 // 3
  return Kadira.connect('uHPo2TkbzrTekecfy', 'cf496f2b-97a3-4588-b4dc-b2dddf0eee25');                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/http","meteor/check","../lib/collections","../imports/months","../imports/tile-config",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _http = require('meteor/http');                                                                                  // 2
                                                                                                                     //
var _check = require('meteor/check');                                                                                // 3
                                                                                                                     //
var _collections = require('../lib/collections');                                                                    // 5
                                                                                                                     //
var _months = require('../imports/months');                                                                          // 7
                                                                                                                     //
var _tileConfig = require('../imports/tile-config');                                                                 // 8
                                                                                                                     //
_ = lodash;                                                                                                          // 10
                                                                                                                     //
var TRUNCATE_LENGTH = 360;                                                                                           // 12
                                                                                                                     //
_meteor.Meteor.methods({                                                                                             // 14
  getDateStr: function () {                                                                                          // 16
    function getDateStr(tile) {                                                                                      //
      (0, _check.check)(tile, Match.Any);                                                                            // 17
                                                                                                                     //
      var startDate = new Date(tile.start);                                                                          // 19
      var endDate = new Date(tile.end);                                                                              // 20
      var start = void 0;                                                                                            // 21
      var end = void 0;                                                                                              // 22
      var date = '';                                                                                                 // 23
                                                                                                                     //
      if (tile.start) {                                                                                              // 25
        start = {                                                                                                    // 26
          date: startDate.getDate(),                                                                                 // 27
          month: _months.months[startDate.getMonth()]                                                                // 28
        };                                                                                                           //
                                                                                                                     //
        date += start.month + ' ' + start.date;                                                                      // 31
      }                                                                                                              //
                                                                                                                     //
      if (tile.end) {                                                                                                // 34
        end = {                                                                                                      // 35
          date: endDate.getDate(),                                                                                   // 36
          month: _months.months[endDate.getMonth()]                                                                  // 37
        };                                                                                                           //
                                                                                                                     //
        if (end.month !== start.month || end.date !== start.date) {                                                  // 40
          date += ' - ';                                                                                             // 41
        }                                                                                                            //
        if (end.month !== start.month) {                                                                             // 43
          date += end.month + ' ';                                                                                   // 44
        }                                                                                                            //
                                                                                                                     //
        if (end.date !== start.date) {                                                                               // 47
          date += end.date;                                                                                          // 48
        }                                                                                                            //
      }                                                                                                              //
                                                                                                                     //
      return date;                                                                                                   // 52
    }                                                                                                                //
                                                                                                                     //
    return getDateStr;                                                                                               //
  }(),                                                                                                               //
  getUniqueValues: function () {                                                                                     // 55
    function getUniqueValues(collection, key) {                                                                      //
      return collection.reduce(function (carry, item) {                                                              // 56
        if (item[key] && ! ~carry.indexOf(item[key])) {                                                              // 57
          carry.push(item[key]);                                                                                     // 58
        }                                                                                                            //
                                                                                                                     //
        return carry;                                                                                                // 61
      }, []).sort();                                                                                                 //
    }                                                                                                                //
                                                                                                                     //
    return getUniqueValues;                                                                                          //
  }(),                                                                                                               //
  truncateText: function () {                                                                                        // 67
    function truncateText() {                                                                                        //
      var text = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];                            //
      var length = arguments.length <= 1 || arguments[1] === undefined ? 360 : arguments[1];                         //
                                                                                                                     //
      (0, _check.check)(text, String);                                                                               // 68
      (0, _check.check)(length, Number);                                                                             // 69
      return '<p>' + _.truncate(text, {                                                                              // 70
        'length': length,                                                                                            // 72
        'separator': /,? +/,                                                                                         // 73
        'omission': ' […]<br><span class = "position bottom right btn btn-text">Read More</span>'                    // 74
      }) + '</p>';                                                                                                   //
    }                                                                                                                //
                                                                                                                     //
    return truncateText;                                                                                             //
  }(),                                                                                                               //
  getMedia: function () {                                                                                            // 80
    function getMedia(mediaObj) {                                                                                    //
      (0, _check.check)(mediaObj, Object);                                                                           // 81
                                                                                                                     //
      var media = [];                                                                                                // 83
                                                                                                                     //
      Object.keys(mediaObj).forEach(function (key) {                                                                 // 85
        return media.push(mediaObj[key]);                                                                            //
      });                                                                                                            //
                                                                                                                     //
      return media;                                                                                                  // 89
    }                                                                                                                //
                                                                                                                     //
    return getMedia;                                                                                                 //
  }(),                                                                                                               //
  mapSocial: function () {                                                                                           // 93
    function mapSocial(tile) {                                                                                       //
      (0, _check.check)(tile, Match.Any);                                                                            // 94
                                                                                                                     //
      var now = Date.parse(new Date());                                                                              // 96
      var timestamp = tile.timestamp * 1000;                                                                         // 97
                                                                                                                     //
      if (tile.url) {                                                                                                // 99
                                                                                                                     //
        return {                                                                                                     // 101
          type: 'social',                                                                                            // 102
          key: tile.id,                                                                                              // 103
          relTimestamp: Math.abs(timestamp - now),                                                                   // 104
          title: tile.user.username,                                                                                 // 105
          link: tile.url,                                                                                            // 106
          caption: tile.caption ? _meteor.Meteor.call('truncateText', tile.caption, TRUNCATE_LENGTH) : null,         // 107
          media: tile.photo ? _meteor.Meteor.call('getMedia', tile.photo) : null,                                    // 108
          config: //Meteor.call( 'getMedia', tile.photo ) : null,                                                    // 109
          _tileConfig.config,                                                                                        //
          timestamp: timestamp                                                                                       // 110
        };                                                                                                           //
      }                                                                                                              //
                                                                                                                     //
      return {                                                                                                       // 114
        type: 'photo',                                                                                               // 115
        key: tile.id,                                                                                                // 116
        relTimestamp: Math.abs(timestamp - now),                                                                     // 117
        media: tile.photo ? [tile.photo.original] : null, config: _tileConfig.config,                                // 118
        timestamp: timestamp                                                                                         // 120
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return mapSocial;                                                                                                //
  }(),                                                                                                               //
  mapEvent: function () {                                                                                            // 125
    function mapEvent(tile) {                                                                                        //
      (0, _check.check)(tile, Match.Any);                                                                            // 126
                                                                                                                     //
      var now = Date.parse(new Date());                                                                              // 128
      var timestamp = Date.parse(tile.start);                                                                        // 129
                                                                                                                     //
      return {                                                                                                       // 131
        type: /*tile.registration.status === 'NOT_REQUIRED' ? 'event' :*/'activity',                                 // 132
        subtype: tile.activityType && tile.activityType.program ? tile.activityType.program.name : '',               // 133
        key: tile.sessionId,                                                                                         // 134
        relTimestamp: Math.abs(timestamp - now),                                                                     // 135
        label: _meteor.Meteor.call('getDateStr', tile),                                                              // 136
        title: tile.title,                                                                                           // 137
        link: 'https://rei.com' + tile.uri,                                                                          // 138
        caption: tile.summary ? _meteor.Meteor.call('truncateText', tile.summary, TRUNCATE_LENGTH) : null,           // 139
        badge: tile.registration.status,                                                                             // 140
                                                                                                                     //
        // Replace when images added to service                                                                      //
        media: _meteor.Meteor.call('getMedia', { placeholder: { url: '/img/test.jpg' } }),                           // 143
        config: _tileConfig.config,                                                                                  // 144
        timestamp: timestamp                                                                                         // 145
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return mapEvent;                                                                                                 //
  }(),                                                                                                               //
  mapPost: function () {                                                                                             // 150
    function mapPost(tile) {                                                                                         //
      (0, _check.check)(tile, Match.Any);                                                                            // 151
                                                                                                                     //
      var now = Date.parse(new Date());                                                                              // 153
      var timestamp = Date.parse(tile.date);                                                                         // 154
                                                                                                                     //
      return {                                                                                                       // 156
        type: 'blog',                                                                                                // 157
        key: tile.id,                                                                                                // 158
        relTimestamp: Math.abs(timestamp - now),                                                                     // 159
        label: 'blog',                                                                                               // 160
        title: tile.title,                                                                                           // 161
        link: tile.url,                                                                                              // 162
        caption: _meteor.Meteor.call('truncateText', tile.excerpt, TRUNCATE_LENGTH),                                 // 163
        media: tile.attachments[0] ? _meteor.Meteor.call('getMedia', tile.attachments[0].images) : [],               // 164
        config: _tileConfig.config,                                                                                  // 165
        timestamp: timestamp                                                                                         // 166
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return mapPost;                                                                                                  //
  }(),                                                                                                               //
  getData: function () {                                                                                             // 171
    function getData(endpoint, query) {                                                                              //
      (0, _check.check)(endpoint, Match.Any);                                                                        // 172
      (0, _check.check)(query, Match.Any);                                                                           // 173
                                                                                                                     //
      var response = void 0;                                                                                         // 175
                                                                                                                     //
      this.unblock();                                                                                                // 177
                                                                                                                     //
      try {                                                                                                          // 179
        console.log('\n::::::: Retrieving Data :::::::\n', 'Endpoint: ' + endpoint + '\n', 'Query:');                // 180
                                                                                                                     //
        Object.keys(query).forEach(function (param) {                                                                // 185
          return console.log('\t' + param + ' : ' + query[param]);                                                   //
        });                                                                                                          //
                                                                                                                     //
        response = _http.HTTP.get(endpoint, {                                                                        // 187
          params: query,                                                                                             // 190
          timeout: 4000                                                                                              // 191
        });                                                                                                          //
        console.log('\n**** Result ****\n', '\tSUCCESS\n');                                                          // 194
                                                                                                                     //
        return response.data;                                                                                        // 196
      } catch (e) {                                                                                                  //
        console.log('\n**** Result ****\n', '\tERROR - CODE: ' + e.code + '\n');                                     // 199
                                                                                                                     //
        return false;                                                                                                // 201
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return getData;                                                                                                  //
  }(),                                                                                                               //
  upsert: function () {                                                                                              // 206
    function upsert(items, map) {                                                                                    //
      (0, _check.check)(items, Match.Any);                                                                           // 207
      (0, _check.check)(map, Match.Any);                                                                             // 208
                                                                                                                     //
      if (items) {                                                                                                   // 210
        console.log('Found ' + items.length + ' items – Mapping and inserting using ' + map + ' schema adaptor...');
                                                                                                                     //
        return items.forEach(function (tile) {                                                                       // 213
          var mapped = _meteor.Meteor.call(map, tile);                                                               // 215
                                                                                                                     //
          _collections.Tiles.update({ _id: mapped.key }, { $set: mapped }, { upsert: true });                        // 217
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return upsert;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"poll.js":["meteor/meteor","../lib/collections","./endpoints",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/poll.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _collections = require('../lib/collections');                                                                    // 2
                                                                                                                     //
var _endpoints = require('./endpoints');                                                                             // 3
                                                                                                                     //
var POLL_INTERVAL = 300000; // 5 min                                                                                 // 9
                                                                                                                     //
function poll() {                                                                                                    // 11
  var curEntries = _collections.Tiles.find().fetch();                                                                // 12
                                                                                                                     //
  console.log('\n---------------- POLLING ( ' + (POLL_INTERVAL / 1000 / 60).toFixed(1) + ' minute interval )----------------\n', 'Initial Tiles collection size: ' + curEntries.length + ' tiles');
                                                                                                                     //
  var newItems = 0;                                                                                                  // 17
                                                                                                                     //
  function getEvents() {                                                                                             // 19
    var events = _meteor.Meteor.call('getData', _endpoints.EVENTS, _endpoints.EVENTS_QUERY);                         // 20
    _meteor.Meteor.call('upsert', events.events, 'mapEvent');                                                        // 21
    return events.events || [];                                                                                      // 22
  }                                                                                                                  //
                                                                                                                     //
  function getPosts() {                                                                                              // 25
    var posts = _meteor.Meteor.call('getData', _endpoints.WP, _endpoints.WP_QUERY);                                  // 26
    _meteor.Meteor.call('upsert', posts.posts, 'mapPost');                                                           // 27
    return posts.posts || [];                                                                                        // 28
  }                                                                                                                  //
                                                                                                                     //
  function getSocial() {                                                                                             // 31
    var social = _meteor.Meteor.call('getData', _endpoints.CURALATE, _endpoints.CURALATE_QUERY);                     // 32
    _meteor.Meteor.call('upsert', social.items, 'mapSocial');                                                        // 33
    return social.items || [];                                                                                       // 34
  }                                                                                                                  //
                                                                                                                     //
  var events = getEvents();                                                                                          // 37
  var posts = getPosts();                                                                                            // 38
  var social = getSocial();                                                                                          // 39
                                                                                                                     //
  /* Result Reporting */                                                                                             //
  var updatedEntries = _collections.Tiles.find().fetch();                                                            // 11
  var retrievedCount = events.length + posts.length + social.length;                                                 // 43
  var difference = updatedEntries.length - curEntries.length;                                                        // 44
  console.log('\n\nNew Tiles collection size:\n     ' + updatedEntries.length + ' tiles ( ' + difference + ' new, ' + (retrievedCount - difference) + ' updated )\n');
}                                                                                                                    //
                                                                                                                     //
poll();                                                                                                              // 51
                                                                                                                     //
_meteor.Meteor.setInterval(poll, POLL_INTERVAL);                                                                     // 53
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","../lib/collections",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications.js                                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _this = this;                                                                                                    //
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _collections = require('../lib/collections');                                                                    // 2
                                                                                                                     //
// Publish collections for consuming client-side                                                                     //
_meteor.Meteor.publish('tiles.public', function () {                                                                 // 5
  var entries = _collections.Tiles.find();                                                                           // 6
                                                                                                                     //
  if (entries) {                                                                                                     // 8
    return entries;                                                                                                  // 9
  }                                                                                                                  //
                                                                                                                     //
  return _this.ready();                                                                                              // 12
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["./poll",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
require('./poll');                                                                                                   // 4
                                                                                                                     //
_ = lodash;                                                                                                          // 1
console.log(process.env.ROOT_URL, process.env.MONGO_URL, process.env.MONGO_OPLOG_URL);                               // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/router.js");
require("./lib/schemas.js");
require("./server/endpoints.js");
require("./server/kadira.js");
require("./server/methods.js");
require("./server/poll.js");
require("./server/publications.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
